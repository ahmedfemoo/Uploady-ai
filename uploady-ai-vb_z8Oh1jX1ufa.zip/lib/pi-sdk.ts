// Pi Network SDK Service
export interface PiUser {
  uid: string
  username: string
}

export interface PiAuthResult {
  accessToken: string
  user: PiUser
}

export interface PiPayment {
  amount: number
  memo: string
  metadata: {
    fileId?: string
    filename?: string
    service: string
    [key: string]: any
  }
}

export interface PiPaymentResult {
  success: boolean
  txId?: string
  paymentId?: string
  amount: number
  timestamp: string
  error?: string
}

export interface PiPaymentCallbacks {
  onReadyForServerApproval: (paymentId: string) => void
  onReadyForServerCompletion: (paymentId: string, txid: string) => void
  onCancel: (paymentId: string) => void
  onError: (error: Error, payment?: any) => void
}

declare global {
  interface Window {
    Pi?: {
      init: (config: { version: string; sandbox: boolean }) => void
      authenticate: (scopes: string[], onIncompletePaymentFound?: (payment: any) => void) => Promise<PiAuthResult>
      createPayment: (paymentData: PiPayment, callbacks: PiPaymentCallbacks) => void
      openShareDialog: (title: string, text: string) => void
    }
  }
}

export class PiSDKService {
  private static instance: PiSDKService
  private isInitialized = false
  private initPromise: Promise<void> | null = null

  private constructor() {}

  public static getInstance(): PiSDKService {
    if (!PiSDKService.instance) {
      PiSDKService.instance = new PiSDKService()
    }
    return PiSDKService.instance
  }

  public async initialize(): Promise<void> {
    if (this.isInitialized) {
      return Promise.resolve()
    }

    if (this.initPromise) {
      return this.initPromise
    }

    this.initPromise = new Promise((resolve, reject) => {
      const checkPiSDK = () => {
        if (typeof window !== "undefined" && window.Pi) {
          try {
            window.Pi.init({
              version: "2.0",
              sandbox: true, // Set to false for production
            })
            this.isInitialized = true
            console.log("Pi SDK initialized successfully")
            resolve()
          } catch (error) {
            console.error("Failed to initialize Pi SDK:", error)
            reject(error)
          }
        } else {
          // Retry after a short delay
          setTimeout(checkPiSDK, 100)
        }
      }

      checkPiSDK()
    })

    return this.initPromise
  }

  public async authenticate(): Promise<PiAuthResult> {
    await this.initialize()

    if (!window.Pi) {
      throw new Error("Pi SDK not available")
    }

    try {
      const auth = await window.Pi.authenticate(["payments", "username"], (payment) => {
        console.log("Incomplete payment found:", payment)
      })

      console.log("Pi authentication successful:", auth.user.username)
      return auth
    } catch (error) {
      console.error("Pi authentication failed:", error)
      throw error
    }
  }

  public async createPayment(paymentData: PiPayment): Promise<PiPaymentResult> {
    await this.initialize()

    if (!window.Pi) {
      throw new Error("Pi SDK not available")
    }

    return new Promise((resolve, reject) => {
      window.Pi!.createPayment(paymentData, {
        onReadyForServerApproval: (paymentId) => {
          console.log("Payment ready for server approval:", paymentId)
          // In a real app, you would send this to your backend for approval
        },
        onReadyForServerCompletion: (paymentId, txid) => {
          console.log("Payment completed:", paymentId, txid)
          resolve({
            success: true,
            txId: txid,
            paymentId: paymentId,
            amount: paymentData.amount,
            timestamp: new Date().toISOString(),
          })
        },
        onCancel: (paymentId) => {
          console.log("Payment cancelled:", paymentId)
          reject(new Error("Payment cancelled by user"))
        },
        onError: (error, payment) => {
          console.error("Payment error:", error, payment)
          reject(error)
        },
      })
    })
  }

  public async shareContent(title: string, text: string): Promise<void> {
    await this.initialize()

    if (!window.Pi) {
      throw new Error("Pi SDK not available")
    }

    window.Pi.openShareDialog(title, text)
  }

  public isAvailable(): boolean {
    return typeof window !== "undefined" && !!window.Pi && this.isInitialized
  }
}

export const piSDK = PiSDKService.getInstance()
