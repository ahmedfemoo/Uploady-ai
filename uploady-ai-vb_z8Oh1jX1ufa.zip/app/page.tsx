"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import {
  Settings,
  Info,
  CloudUpload,
  Moon,
  Sun,
  Folder,
  FileText,
  ImageIcon,
  Archive,
  MoreVertical,
  CheckCircle,
  X,
  Coins,
  ShoppingCart,
} from "lucide-react"
import { Input } from "@/components/ui/input"
import { piSDK } from "@/lib/pi-sdk"

interface Translations {
  [key: string]: {
    appName: string
    uploadButton: string
    settings: string
    info: string
    language: string
    theme: string
    lightMode: string
    darkMode: string
    aboutTitle: string
    aboutDescription: string
    selectLanguage: string
    blockchainIntegration: string
    costPerGB: string
    uploadFiles: string
    createFolder: string
    myFiles: string
    storage: string
    wallet: string
    connectWallet: string
    walletConnected: string
    balance: string
    storageUsed: string
    uploadProgress: string
    dragDropFiles: string
    recentUploads: string
    folders: string
    selectFile: string
    uploadAndAnalyze: string
    aiProcessing: string
    ipfsUpload: string
    paymentRequired: string
    payNow: string
    uploadComplete: string
    cid: string
    aiAnalysis: string
    paymentConfirmed: string
    fileDetails: string
    processingFile: string
    uploadingToIPFS: string
    confirmingPayment: string
    viewOnIPFS: string
    copyLink: string
    uploadAnother: string
    paymentDialogTitle: string
    paymentAmountLabel: string
    confirmPaymentButton: string
    cancelPaymentButton: string
  }
}

const translations: Translations = {
  en: {
    appName: "Uploady",
    uploadButton: "Upload on Blockchain",
    settings: "Settings",
    info: "Info",
    language: "Language",
    theme: "Theme",
    lightMode: "Light Mode",
    darkMode: "Dark Mode",
    aboutTitle: "About Uploady - Web3 Storage",
    aboutDescription:
      'Uploady is a next-generation Web3 application designed to revolutionize how users store and manage their files securely on the Pi Network. Powered by decentralized infrastructure, Uploady allows unlimited file uploads with seamless organization — all backed by encryption and transparency.\n\nThrough Pi Network integration, users can effortlessly upload files and folders directly from their devices. Each file is encrypted, tokenized, and stored permanently on-chain. The cost? Just 0.001 π per file, making Uploady one of the most affordable decentralized storage platforms on the Pi Network.\n\nThe app features a clean, professional interface with smooth file and folder management. Users can create folders, sort files, preview uploads, and track storage usage — all within a beautifully designed and intuitive UI.\n\nThe welcome screen presents a polished look with the app\'s name "Uploady" and a centered icon button labeled "Upload on Blockchain", inviting users to get started instantly.\n\nWhether you\'re an individual looking for secure backups or a business seeking decentralized document management, Uploady ensures your data stays private, encrypted, and always accessible — without limitations.\n\nExperience the future of digital storage — simple, secure, and powered by Pi Network.',
    selectLanguage: "Select Language",
    blockchainIntegration: "AI-Powered Web3 Storage",
    costPerGB: "0.001 π per file",
    uploadFiles: "Upload Files",
    createFolder: "Create Folder",
    myFiles: "My Files",
    storage: "Storage",
    wallet: "Wallet",
    connectWallet: "Connect Wallet",
    walletConnected: "Wallet Connected",
    balance: "Balance",
    storageUsed: "Storage Used",
    uploadProgress: "Uploading...",
    dragDropFiles: "Drag & drop files here or click to browse",
    recentUploads: "Recent Uploads",
    folders: "Folders",
    selectFile: "Select File",
    uploadAndAnalyze: "Upload & Analyze",
    aiProcessing: "AI Processing...",
    ipfsUpload: "Uploading to IPFS...",
    paymentRequired: "Payment Required",
    payNow: "Pay 0.001 π",
    uploadComplete: "Upload Complete",
    cid: "IPFS CID",
    aiAnalysis: "AI Analysis",
    paymentConfirmed: "Payment Confirmed",
    fileDetails: "File Details",
    processingFile: "Processing file with AI...",
    uploadingToIPFS: "Uploading to IPFS network...",
    confirmingPayment: "Confirming payment...",
    viewOnIPFS: "View on IPFS",
    copyLink: "Copy Link",
    uploadAnother: "Upload Another File",
    paymentDialogTitle: "Payment Required",
    paymentAmountLabel: "Payment Amount",
    confirmPaymentButton: "Confirm Payment",
    cancelPaymentButton: "Cancel",
  },
  ar: {
    appName: "أبلودي",
    uploadButton: "رفع على البلوك تشين",
    settings: "الإعدادات",
    info: "معلومات",
    language: "اللغة",
    theme: "المظهر",
    lightMode: "الوضع الفاتات",
    darkMode: "الوضع الداكن",
    aboutTitle: "حول أبلودي - تخزين ويب3",
    aboutDescription:
      'أبلودي هو تطبيق ويب3 من الجيل التالي مصمم لثورة في طريقة تخزين المستخدمين وإدارة ملفاتهم بأمان على Pi Network. مدعوم بالبنية التحتية اللامركزية، يتيح أبلودي رفع ملفات غير محدود مع تنظيم سلس — كل ذلك مدعوم بالتشفير والشفافية.\n\nمن خلال وكامل Pi Network، يمكن للمستخدمين رفع الملفات والمجلدات بسهولة مباشرة من أجهزتهم. كل ملف يتم تشفيره وترميزه وتخزينه بشكل دائم على السلسلة. التكلفة؟ فقط 0.001 π لكل ملف، مما يجعل أبلودي واحدًا من أكثر منصات التخزين اللامركزية بأسعار معقولة على Pi Network.\n\nيتميز التطبيق بواجهة نظيفة ومهنية مع إدارة سلسة للملفات والمجلدات. يمكن للمستخدمين إنشاء مجلدات وترتيب الملفات ومعاينة الرفوعات وتتبع استخدام التخزين — كل ذلك ضمن واجهة مستخدم مصممة بجمال وبديهية.\n\nتقدم شاشة الترحيب مظهرًا مصقولًا مع اسم التطبيق "أبلودي" وزر أيقونة في المنتصف بعنوان "رفع على البلوك تشين"، يدعو المستخدمين للبدء فورًا.\n\nسواء كنت فردًا تبحث عن نسخ احتياطية آمنة أو شركة تسعى لإدارة مستندات لفلاكية، يضمن أبلودي أن تبقى بياناتك خاصة ومشفرة ومتاحة دائمًا — بدون قيود.\n\nاختبر مستقبل التخزين الرقمي — بسيط وآمن ومدعوم بتقنية Pi Network.',
    selectLanguage: "اختر اللغة",
    blockchainIntegration: "تكامل البلوك تشين",
    costPerGB: "0.001 π لكل ملف",
    uploadFiles: "رفع ملفات",
    createFolder: "إنشاء مجلد",
    myFiles: "ملفاتي",
    storage: "تخزين",
    wallet: "محفظة",
    connectWallet: "ربط محفظة",
    walletConnected: "تم ربط المحفظة",
    balance: "الرصيد",
    storageUsed: "التخزين المستخدم",
    uploadProgress: "جارٍ التحميل...",
    dragDropFiles: "اسحب وأفلت الملفات هنا أو انقر للتصفح",
    recentUploads: "التحميلات الأخيرة",
    folders: "المجلدات",
    selectFile: "اختر ملف",
    uploadAndAnalyze: "رفع وتحليل",
    aiProcessing: "معالجة الذكاء الاصطناعي...",
    ipfsUpload: "جارٍ الرفع إلى IPFS...",
    paymentRequired: "الدفع مطلوب",
    payNow: "ادفع 0.001 π",
    uploadComplete: "اكتمل الرفع",
    cid: "IPFS CID",
    aiAnalysis: "تحليل الذكاء الاصطناعي",
    paymentConfirmed: "تم تأكيد الدفع",
    fileDetails: "تفاصيل الملف",
    processingFile: "جاري معالجة الملف بالذكاء الاصطناعي...",
    uploadingToIPFS: "جاري الرفع إلى شبكة IPFS...",
    confirmingPayment: "جاري تأكيد الدفع...",
    viewOnIPFS: "عرض على IPFS",
    copyLink: "نسخ الرابط",
    uploadAnother: "رفع ملف آخر",
    paymentDialogTitle: "الدفع مطلوب",
    paymentAmountLabel: "مبلغ الدفع",
    confirmPaymentButton: "تأكيد الدفع",
    cancelPaymentButton: "إلغاء",
  },
  es: {
    appName: "Uploady",
    uploadButton: "Subir en Blockchain",
    settings: "Configuración",
    info: "Información",
    language: "Idioma",
    theme: "Tema",
    lightMode: "Modo Claro",
    darkMode: "Modo Oscuro",
    aboutTitle: "Acerca de Uploady - Almacenamiento Web3",
    aboutDescription:
      'Uploady es una aplicación Web3 de próxima generación diseñada para revolucionar cómo los usuarios almacenan y gestionan sus archivos de forma segura en la Pi Network. Impulsado por infraestructura descentralizada, Uploady permite cargas de archivos ilimitadas con organización perfecta — todo respaldado por encriptación y transparencia.\n\nA través de la integración Pi Network, los usuarios pueden cargar archivos y carpetas sin esfuerzo directamente desde sus dispositivos. Cada archivo se encripta, tokeniza y almacena permanentemente en cadena. ¿El costo? Solo 0.001 π por archivo, haciendo de Uploady una de las plataformas de almacenamiento descentralizado más asequibles en la Pi Network.\n\nLa aplicación presenta una interfaz limpia y profesional con gestión fluida de archivos y carpetas. Los usuarios pueden crear carpetas, ordenar archivos, previsualizar cargas y rastrear el uso de almacenamiento — todo dentro de una UI bellamente diseñada e intuitiva.\n\nLa pantalla de bienvenida presenta un aspecto pulido con el nombre de la aplicación "Uploady" y un botón de icono centrado etiquetado "Subir en Blockchain", invitando a los usuarios a comenzar instantáneamente.\n\nYa seas un individuo buscando respaldos seguros o una empresa buscando gestión de documentos descentralizada, Uploady asegura que tus datos permanezcan privados, encriptados y siempre accesibles — sin limitaciones.\n\nExperimenta el futuro del almacenamiento digital — simple, seguro y potenciado por Pi Network.',
    selectLanguage: "Seleccionar Idioma",
    blockchainIntegration: "Integración Blockchain",
    costPerGB: "0.001 π por archivo",
    uploadFiles: "Subir Archivos",
    createFolder: "Crear Carpeta",
    myFiles: "Mis Archivos",
    storage: "Almacenamiento",
    wallet: "Billetera",
    connectWallet: "Conectar Billetera",
    walletConnected: "Billetera Conectada",
    balance: "Balance",
    storageUsed: "Almacenamiento Usado",
    uploadProgress: "Subiendo...",
    dragDropFiles: "Arrastra y suelta archivos aquí o haz clic para explorar",
    recentUploads: "Cargas Recientes",
    folders: "Carpetas",
    selectFile: "Seleccionar Archivo",
    uploadAndAnalyze: "Subir y Analizar",
    aiProcessing: "Procesamiento de IA...",
    ipfsUpload: "Subiendo a IPFS...",
    paymentRequired: "Pago Requerido",
    payNow: "Pagar 0.001 π",
    uploadComplete: "Subida Completa",
    cid: "IPFS CID",
    aiAnalysis: "Análisis de IA",
    paymentConfirmed: "Pago Confirmado",
    fileDetails: "Detalles del Archivo",
    processingFile: "Procesando archivo con IA...",
    uploadingToIPFS: "Subiendo a la red IPFS...",
    confirmingPayment: "Confirmando pago...",
    viewOnIPFS: "Ver en IPFS",
    copyLink: "Copiar Enlace",
    uploadAnother: "Subir Otro Archivo",
    paymentDialogTitle: "Pago Requerido",
    paymentAmountLabel: "Monto del Pago",
    confirmPaymentButton: "Confirmar Pago",
    cancelPaymentButton: "Cancelar",
  },
  fr: {
    appName: "Uploady",
    uploadButton: "Télécharger sur Blockchain",
    settings: "Paramètres",
    info: "Informations",
    language: "Langue",
    theme: "Thème",
    lightMode: "Mode Clair",
    darkMode: "Mode Sombre",
    aboutTitle: "À propos d'Uploady - Stockage Web3",
    aboutDescription:
      "Uploady est une application Web3 de nouvelle génération conçue pour révolutionner la façon dont les utilisateurs stockent et gèrent leurs fichiers en toute sécurité sur la Pi Network. Alimenté par une infrastructure décentralisée, Uploady permet des téléchargements de fichiers illimités avec une organisation transparente — le tout soutenu par le chiffrement et la transparence.\n\nGrâce à l'intégration Pi Network, les utilisateurs peuvent télécharger sans effort des fichiers et dossiers directement depuis leurs appareils. Chaque fichier est chiffré, tokenisé et stocké de façon permanente sur la chaîne. Le coût ? Seulement 0,001 π par fichier, faisant d'Uploady l'une des plateformes de stockage décentralisé les plus abordables sur la Pi Network.\n\nL'application présente une interface propre et professionnelle avec une gestion fluide des fichiers et dossiers. Les utilisateurs peuvent créer des dossiers, trier les fichiers, prévisualiser les téléchargements et suivre l'utilisation du stockage — le tout dans une interface utilisateur magnifiquement conçue et intuitive.\n\nL'écran d'accueil présente un aspect poli avec le nom de l'application \"Uploady\" et un bouton d'icône centré intitulé \"Télécharger sur Blockchain\", invitant les utilisateurs à commencer instantanément.\n\nQue vous soyez un individu cherchant des sauvegardes sécurisées ou une entreprise cherchant une gestion de documents décentralisée, Uploady assure que vos données restent privées, chiffrées et toujours accessibles — sans limitations.\n\nDécouvrez l'avenir du stockage numérique — simple, sécurisé et alimenté par la technologie Pi Network.",
    selectLanguage: "Sélectionner la Langue",
    blockchainIntegration: "Intégration Blockchain",
    costPerGB: "0,001 π par fichier",
    uploadFiles: "Télécharger des Fichiers",
    createFolder: "Créer un Dossier",
    myFiles: "Mes Fichiers",
    storage: "Stockage",
    wallet: "Portefeuille",
    connectWallet: "Connecter le Portefeuille",
    walletConnected: "Portefeuille Connecté",
    balance: "Solde",
    storageUsed: "Stockage Utilisé",
    uploadProgress: "Téléchargement...",
    dragDropFiles: "Glissez-déposez des fichiers ici ou cliquez pour parcourir",
    recentUploads: "Téléchargements Récents",
    folders: "Dossiers",
    selectFile: "Sélectionner un Fichier",
    uploadAndAnalyze: "Télécharger et Analyser",
    aiProcessing: "Traitement IA...",
    ipfsUpload: "Téléchargement vers IPFS...",
    paymentRequired: "Paiement Requis",
    payNow: "Payer 0.001 π",
    uploadComplete: "Téléchargement Terminé",
    cid: "IPFS CID",
    aiAnalysis: "Analyse IA",
    paymentConfirmed: "Paiement Confirmé",
    fileDetails: "Détails du Fichier",
    processingFile: "Traitement du fichier avec l'IA...",
    uploadingToIPFS: "Téléchargement vers le réseau IPFS...",
    confirmingPayment: "Confirmation du paiement...",
    viewOnIPFS: "Voir sur IPFS",
    copyLink: "Copier le Lien",
    uploadAnother: "Télécharger un autre Fichier",
    paymentDialogTitle: "Paiement Requis",
    paymentAmountLabel: "Montant du Paiement",
    confirmPaymentButton: "Confirmer le Paiement",
    cancelPaymentButton: "Annuler",
  },
}

export default function UploadyApp() {
  const [isDarkMode, setIsDarkMode] = useState(true)
  const [language, setLanguage] = useState("en")
  const [isSettingsOpen, setIsSettingsOpen] = useState(false)
  const [currentScreen, setCurrentScreen] = useState("welcome")
  const [files, setFiles] = useState<any[]>([])
  const [uploadProgress, setUploadProgress] = useState(0)
  const [isUploading, setIsUploading] = useState(false)
  const [isProcessing, setIsProcessing] = useState(false)
  const [walletConnected, setWalletConnected] = useState(false)
  const [storageUsed, setStorageUsed] = useState(0) // GB
  const [storageLimit] = useState(Number.POSITIVE_INFINITY) // GB
  const [balance, setBalance] = useState(15.7) // Pi
  const [selectedFile, setSelectedFile] = useState<any>(null)
  const [aiAnalysis, setAiAnalysis] = useState<any>(null)
  const [uploadedCID, setUploadedCID] = useState<string | null>(null)
  const [paymentStatus, setPaymentStatus] = useState<any>(null)
  const [uploadHistory, setUploadHistory] = useState<any[]>([])
  const [folders, setFolders] = useState([
    { id: 1, name: "Documents", count: 24, icon: FileText, color: "blue" },
    { id: 2, name: "Images", count: 156, icon: ImageIcon, color: "green" },
    { id: 3, name: "Projects", count: 8, icon: Folder, color: "purple" },
    { id: 4, name: "Archives", count: 12, icon: Archive, color: "yellow" },
  ])
  const [editingFolder, setEditingFolder] = useState<number | null>(null)
  const [newFolderName, setNewFolderName] = useState("")
  const [showNewFolderDialog, setShowNewFolderDialog] = useState(false)
  const [isPaymentDialogOpen, setIsPaymentDialogOpen] = useState(false)
  const [isProcessingPayment, setIsProcessingPayment] = useState(false)
  const [paymentAmount, setPaymentAmount] = useState("0.001")

  const [isBuyDialogOpen, setIsBuyDialogOpen] = useState(false)
  const [selectedPlan, setSelectedPlan] = useState<"storage" | "premium">("storage")
  const [isProcessingPurchase, setIsProcessingPurchase] = useState(false)

  const buyPlans = {
    storage: [
      { size: "100GB", price: 5, description: "Perfect for regular use" },
      { size: "500GB", price: 20, description: "Great for power users" },
      { size: "1TB", price: 35, description: "Ultimate storage capacity" },
    ],
    premium: [
      { name: "Pro", price: 10, features: ["Unlimited uploads", "Priority support", "Advanced encryption"] },
      { name: "Business", price: 25, features: ["Everything in Pro", "Team collaboration", "API access"] },
    ],
  }

  const t = translations[language]

  const handleThemeToggle = () => {
    setIsDarkMode(!isDarkMode)
  }

  const handleLanguageChange = (language: string) => {
    setLanguage(language)
  }

  const themeClasses = isDarkMode
    ? "bg-gradient-to-br from-purple-900 via-slate-900 to-black"
    : "bg-gradient-to-br from-blue-50 via-white to-blue-100"

  const textClasses = isDarkMode ? "text-white" : "text-gray-900"
  const subtextClasses = isDarkMode ? "text-gray-300" : "text-gray-600"
  const cardClasses = isDarkMode
    ? "bg-white/10 backdrop-blur-sm border-white/20"
    : "bg-white/80 backdrop-blur-sm border-gray-200/50"

  const createNewFolder = () => {
    if (newFolderName.trim()) {
      const newFolder = {
        id: Date.now(),
        name: newFolderName.trim(),
        count: 0,
        icon: Folder,
        color: "purple",
      }
      setFolders((prev) => [...prev, newFolder])
      setNewFolderName("")
      setShowNewFolderDialog(false)
    }
  }

  const renameFolder = (id: number, newName: string) => {
    if (newName.trim()) {
      setFolders((prev) => prev.map((folder) => (folder.id === id ? { ...folder, name: newName.trim() } : folder)))
    }
    setEditingFolder(null)
  }

  const deleteFolder = (id: number) => {
    setFolders((prev) => prev.filter((folder) => folder.id !== id))
  }

  const handleUpload = async () => {
    if (!walletConnected) {
      alert(t.connectWallet)
      return
    }

    if (balance < Number.parseFloat(paymentAmount)) {
      setIsPaymentDialogOpen(true)
      return
    }

    setIsUploading(true)
    setUploadProgress(0)

    // Simulate file upload and payment process
    setTimeout(async () => {
      setUploadProgress(100)
      setUploadedCID("QmExampleCID")
      setPaymentStatus("confirmed")

      // Process payment using Pi SDK
      await piSDK.processPayment(Number.parseFloat(paymentAmount))

      // Update balance
      setBalance(balance - Number.parseFloat(paymentAmount))

      // Simulate AI processing
      setTimeout(() => {
        setAiAnalysis("AI Analysis Result")
        setIsProcessing(false)
        setIsUploading(false)
        setCurrentScreen("uploadComplete")
      }, 2000)
    }, 3000)
  }

  const handleBuyWithPi = async (amount: number, item: string) => {
    if (!walletConnected) {
      return
    }

    setIsProcessingPurchase(true)
    try {
      const result = await piSDK.createPayment({
        amount: amount,
        memo: `Purchase: ${item}`,
        metadata: {
          service: "uploady-purchase",
          item: item,
          timestamp: new Date().toISOString(),
        },
      })

      if (result.success) {
        setBalance((prev) => prev - amount)
        setIsBuyDialogOpen(false)
        // Show success message or update storage capacity
      }
    } catch (error) {
      console.error("Purchase failed:", error)
    } finally {
      setIsProcessingPurchase(false)
    }
  }

  const handlePiPayment = async () => {
    try {
      setIsProcessingPayment(true)

      const result = await piSDK.createPayment({
        amount: Number.parseFloat(paymentAmount),
        memo: "Uploady file storage payment",
        metadata: {
          service: "file-storage",
          timestamp: new Date().toISOString(),
        },
      })

      if (result.success) {
        // Update balance after successful payment
        setBalance((prev) => prev - Number.parseFloat(paymentAmount))
        setIsPaymentDialogOpen(false)
        alert(`Payment successful! Transaction ID: ${result.txId}`)
      }
    } catch (error) {
      console.error("Payment failed:", error)
      alert("Payment cancelled or failed")
    } finally {
      setIsProcessingPayment(false)
    }
  }

  if (currentScreen === "welcome") {
    return (
      <div className={`min-h-screen ${themeClasses} transition-all duration-500`}>
        <header className="flex justify-end items-center p-6 space-x-3">
          <Sheet open={isSettingsOpen} onOpenChange={setIsSettingsOpen}>
            <SheetTrigger asChild>
              <Button
                size="icon"
                variant="ghost"
                className={`w-10 h-10 rounded-full ${
                  isDarkMode
                    ? "hover:bg-white/10 text-gray-300 hover:text-white"
                    : "hover:bg-gray-100 text-gray-600 hover:text-gray-900"
                }`}
              >
                <Settings className="w-5 h-5" />
              </Button>
            </SheetTrigger>
            <SheetContent
              side="right"
              className={`${
                isDarkMode
                  ? "bg-slate-900/95 backdrop-blur-sm border-white/20"
                  : "bg-white/95 backdrop-blur-sm border-gray-200"
              }`}
            >
              <SheetHeader>
                <SheetTitle className={textClasses}>{t.settings}</SheetTitle>
              </SheetHeader>
              <div className="mt-6 space-y-6">
                <div className="space-y-2">
                  <Label className={textClasses}>{t.language}</Label>
                  <Select value={language} onValueChange={setLanguage}>
                    <SelectTrigger className={isDarkMode ? "bg-slate-900 border-white/20" : ""}>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="en">English</SelectItem>
                      <SelectItem value="ar">العربية</SelectItem>
                      <SelectItem value="es">Español</SelectItem>
                      <SelectItem value="fr">Français</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex items-center justify-between">
                  <Label className={textClasses}>{t.theme}</Label>
                  <div className="flex items-center space-x-2">
                    <Sun className={`w-4 h-4 ${textClasses}`} />
                    <Switch checked={isDarkMode} onCheckedChange={setIsDarkMode} />
                    <Moon className={`w-4 h-4 ${textClasses}`} />
                  </div>
                </div>
              </div>
            </SheetContent>
          </Sheet>

          <Dialog>
            <DialogTrigger asChild>
              <Button
                size="icon"
                variant="ghost"
                className={`w-10 h-10 rounded-full ${
                  isDarkMode
                    ? "hover:bg-white/10 text-gray-300 hover:text-white"
                    : "hover:bg-gray-100 text-gray-600 hover:text-gray-900"
                }`}
              >
                <Info className="w-5 h-5" />
              </Button>
            </DialogTrigger>
            <DialogContent
              className={`max-w-2xl ${
                isDarkMode
                  ? "bg-slate-900/95 backdrop-blur-sm border-white/20"
                  : "bg-white/95 backdrop-blur-sm border-gray-200"
              }`}
            >
              <DialogHeader>
                <DialogTitle className={textClasses}>{t.aboutTitle}</DialogTitle>
              </DialogHeader>
              <div className="flex flex-col gap-4 max-h-[60vh] overflow-y-auto">
                <p className={`${subtextClasses} whitespace-pre-wrap`}>{t.aboutDescription}</p>
              </div>
            </DialogContent>
          </Dialog>
        </header>

        <main className="flex flex-col items-center justify-center min-h-[calc(100vh-120px)] p-6">
          <h1 className={`text-5xl font-bold mb-4 ${textClasses}`}>{t.appName}</h1>
          <p className={`${subtextClasses} text-lg mb-8 text-center`}>{t.blockchainIntegration}</p>

          {/* Animated blockchain symbol with glowing files moving between blocks */}
          <div className="relative w-64 h-32 mb-8 flex items-center justify-center">
            {/* Blockchain Blocks */}
            <div className="absolute left-0 w-16 h-16 rounded-lg bg-gradient-to-br from-purple-500 to-purple-700 shadow-lg animate-pulse-slow flex items-center justify-center">
              <div className="w-10 h-10 border-2 border-white/40 rounded" />
            </div>
            <div
              className="absolute left-1/2 -translate-x-1/2 w-16 h-16 rounded-lg bg-gradient-to-br from-blue-500 to-blue-700 shadow-lg animate-pulse-slow-delay flex items-center justify-center"
              style={{ animationDelay: "0.3s" }}
            >
              <div className="w-10 h-10 border-2 border-white/40 rounded" />
            </div>
            <div
              className="absolute right-0 w-16 h-16 rounded-lg bg-gradient-to-br from-pink-500 to-pink-700 shadow-lg animate-pulse-slow-delay flex items-center justify-center"
              style={{ animationDelay: "0.6s" }}
            >
              <div className="w-10 h-10 border-2 border-white/40 rounded" />
            </div>

            {/* Connection Lines with Glow */}
            <div className="absolute left-16 top-1/2 w-16 h-0.5 bg-gradient-to-r from-purple-400 to-blue-400 shadow-[0_0_10px_rgba(147,51,234,0.5)] animate-pulse" />
            <div
              className="absolute right-16 top-1/2 w-16 h-0.5 bg-gradient-to-r from-blue-400 to-pink-400 shadow-[0_0_10px_rgba(59,130,246,0.5)] animate-pulse"
              style={{ animationDelay: "0.3s" }}
            />

            {/* Glowing File Icons Moving Between Blocks */}
            <FileText
              className="absolute w-5 h-5 text-white animate-file-transfer-1"
              style={{
                filter: "drop-shadow(0 0 8px rgba(147,51,234,0.8))",
                left: "20%",
                top: "50%",
                transform: "translate(-50%, -50%)",
              }}
            />
            <ImageIcon
              className="absolute w-5 h-5 text-white animate-file-transfer-2"
              style={{
                filter: "drop-shadow(0 0 8px rgba(59,130,246,0.8))",
                left: "50%",
                top: "50%",
                transform: "translate(-50%, -50%)",
              }}
            />
            <Archive
              className="absolute w-5 h-5 text-white animate-file-transfer-3"
              style={{
                filter: "drop-shadow(0 0 8px rgba(236,72,153,0.8))",
                left: "80%",
                top: "50%",
                transform: "translate(-50%, -50%)",
              }}
            />
          </div>

          <Button
            size="lg"
            className="px-8 py-4 text-lg rounded-full shadow-lg bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
            onClick={() => setCurrentScreen("upload")}
          >
            {t.uploadButton}
          </Button>
        </main>

        <footer className="absolute bottom-0 left-0 right-0 p-6 text-center">
          <p className={`${subtextClasses}`}>{t.costPerGB}</p>
        </footer>
      </div>
    )
  }

  if (currentScreen === "upload" || currentScreen === "filesInFolder") {
    return (
      <div className={`min-h-screen ${themeClasses} transition-all duration-500 pb-20`}>
        <header className="flex justify-between items-center p-6">
          <h1 className={`text-3xl font-bold ${textClasses}`}>{t.appName}</h1>
          <div className="flex items-center space-x-3">
            <Button
              size="sm"
              variant={walletConnected ? "default" : "outline"}
              onClick={() => setWalletConnected(!walletConnected)}
              className={
                walletConnected
                  ? "bg-green-600 hover:bg-green-700"
                  : isDarkMode
                    ? "border-white/20 text-white hover:bg-white/10"
                    : "border-gray-200 text-gray-700 hover:bg-gray-100"
              }
            >
              {walletConnected ? (
                <>
                  <CheckCircle className="w-4 h-4 mr-2" />
                  {balance.toFixed(2)} π
                </>
              ) : (
                t.connectWallet
              )}
            </Button>

            <Dialog open={isPaymentDialogOpen} onOpenChange={setIsPaymentDialogOpen}>
              <DialogTrigger asChild>
                <Button
                  size="sm"
                  variant="default"
                  className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                  disabled={!walletConnected}
                >
                  <Coins className="w-4 h-4 mr-2" />
                  Pay with Pi
                </Button>
              </DialogTrigger>
              <DialogContent
                className={`${
                  isDarkMode
                    ? "bg-slate-900/95 backdrop-blur-sm border-white/20"
                    : "bg-white/95 backdrop-blur-sm border-gray-200"
                }`}
              >
                <DialogHeader>
                  <DialogTitle className={textClasses}>Pi Network Payment</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label htmlFor="amount" className={textClasses}>
                      Amount (π)
                    </Label>
                    <Input
                      id="amount"
                      type="number"
                      step="0.001"
                      value={paymentAmount}
                      onChange={(e) => setPaymentAmount(e.target.value)}
                      className={
                        isDarkMode
                          ? "bg-slate-800 border-white/20 text-white"
                          : "bg-white border-gray-200 text-gray-900"
                      }
                    />
                  </div>
                  <div className={`p-4 rounded-lg ${isDarkMode ? "bg-slate-800/50" : "bg-gray-50"}`}>
                    <p className={`text-sm ${textClasses} mb-2`}>Current Balance: {balance.toFixed(3)} π</p>
                    <p className={`text-sm ${textClasses}`}>
                      After Payment: {(balance - Number.parseFloat(paymentAmount || "0")).toFixed(3)} π
                    </p>
                  </div>
                  <Button
                    onClick={handlePiPayment}
                    disabled={isProcessingPayment || Number.parseFloat(paymentAmount) > balance}
                    className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                  >
                    {isProcessingPayment ? "Processing..." : `Pay ${paymentAmount} π`}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>

            <Dialog open={isBuyDialogOpen} onOpenChange={setIsBuyDialogOpen}>
              <DialogTrigger asChild>
                <Button
                  size="sm"
                  variant="default"
                  className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700"
                  disabled={!walletConnected}
                >
                  <ShoppingCart className="w-4 h-4 mr-2" />
                  Buy
                </Button>
              </DialogTrigger>
              <DialogContent
                className={`${
                  isDarkMode
                    ? "bg-slate-900/95 backdrop-blur-sm border-white/20"
                    : "bg-white/95 backdrop-blur-sm border-gray-200"
                } max-w-2xl`}
              >
                <DialogHeader>
                  <DialogTitle className={textClasses}>Purchase with Pi Network</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  {/* Plan Selection Tabs */}
                  <div className="flex gap-2 mb-4">
                    <Button
                      variant={selectedPlan === "storage" ? "default" : "outline"}
                      onClick={() => setSelectedPlan("storage")}
                      className={`flex-1 ${
                        selectedPlan === "storage"
                          ? "bg-gradient-to-r from-purple-600 to-blue-600"
                          : isDarkMode
                            ? "border-white/20"
                            : "border-gray-200"
                      }`}
                    >
                      Storage Plans
                    </Button>
                    <Button
                      variant={selectedPlan === "premium" ? "default" : "outline"}
                      onClick={() => setSelectedPlan("premium")}
                      className={`flex-1 ${
                        selectedPlan === "premium"
                          ? "bg-gradient-to-r from-purple-600 to-blue-600"
                          : isDarkMode
                            ? "border-white/20"
                            : "border-gray-200"
                      }`}
                    >
                      Premium Plans
                    </Button>
                  </div>

                  {/* Storage Plans */}
                  {selectedPlan === "storage" && (
                    <div className="grid gap-4">
                      {buyPlans.storage.map((plan) => (
                        <div
                          key={plan.size}
                          className={`p-4 rounded-lg border-2 ${
                            isDarkMode
                              ? "bg-slate-800/50 border-white/10 hover:border-purple-500/50"
                              : "bg-gray-50 border-gray-200 hover:border-purple-500/50"
                          } transition-all cursor-pointer`}
                        >
                          <div className="flex items-center justify-between mb-2">
                            <div>
                              <h3 className={`text-lg font-bold ${textClasses}`}>{plan.size} Storage</h3>
                              <p className={`text-sm ${subtextClasses}`}>{plan.description}</p>
                            </div>
                            <div className="text-right">
                              <div className={`text-2xl font-bold ${textClasses}`}>{plan.price} π</div>
                            </div>
                          </div>
                          <Button
                            onClick={() => handleBuyWithPi(plan.price, `${plan.size} Storage`)}
                            disabled={isProcessingPurchase || balance < plan.price}
                            className="w-full bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 mt-2"
                          >
                            {isProcessingPurchase ? "Processing..." : `Buy for ${plan.price} π`}
                          </Button>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Premium Plans */}
                  {selectedPlan === "premium" && (
                    <div className="grid gap-4">
                      {buyPlans.premium.map((plan) => (
                        <div
                          key={plan.name}
                          className={`p-4 rounded-lg border-2 ${
                            isDarkMode
                              ? "bg-slate-800/50 border-white/10 hover:border-purple-500/50"
                              : "bg-gray-50 border-gray-200 hover:border-purple-500/50"
                          } transition-all cursor-pointer`}
                        >
                          <div className="flex items-center justify-between mb-3">
                            <div>
                              <h3 className={`text-lg font-bold ${textClasses}`}>{plan.name} Plan</h3>
                              <div className={`text-2xl font-bold ${textClasses} mt-1`}>{plan.price} π/month</div>
                            </div>
                          </div>
                          <ul className="space-y-2 mb-3">
                            {plan.features.map((feature, idx) => (
                              <li key={idx} className={`flex items-start gap-2 text-sm ${subtextClasses}`}>
                                <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                                {feature}
                              </li>
                            ))}
                          </ul>
                          <Button
                            onClick={() => handleBuyWithPi(plan.price, `${plan.name} Plan`)}
                            disabled={isProcessingPurchase || balance < plan.price}
                            className="w-full bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700"
                          >
                            {isProcessingPurchase ? "Processing..." : `Subscribe for ${plan.price} π/month`}
                          </Button>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Balance Info */}
                  <div className={`p-4 rounded-lg ${isDarkMode ? "bg-slate-800/50" : "bg-gray-50"} mt-4`}>
                    <p className={`text-sm ${textClasses}`}>Your Balance: {balance.toFixed(3)} π</p>
                  </div>
                </div>
              </DialogContent>
            </Dialog>

            <Sheet open={isSettingsOpen} onOpenChange={setIsSettingsOpen}>
              <SheetTrigger asChild>
                <Button
                  size="icon"
                  variant="ghost"
                  className={`w-10 h-10 rounded-full ${
                    isDarkMode
                      ? "hover:bg-white/10 text-gray-300 hover:text-white"
                      : "hover:bg-gray-100 text-gray-600 hover:text-gray-900"
                  }`}
                >
                  <Settings className="w-5 h-5" />
                </Button>
              </SheetTrigger>
              <SheetContent
                side="right"
                className={`${
                  isDarkMode
                    ? "bg-slate-900/95 backdrop-blur-sm border-white/20"
                    : "bg-white/95 backdrop-blur-sm border-gray-200"
                }`}
              >
                <SheetHeader>
                  <SheetTitle className={textClasses}>{t.settings}</SheetTitle>
                </SheetHeader>
                <div className="mt-6 space-y-6">
                  <div className="space-y-2">
                    <Label className={textClasses}>{t.language}</Label>
                    <Select value={language} onValueChange={setLanguage}>
                      <SelectTrigger className={isDarkMode ? "bg-slate-800 border-white/20" : ""}>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="en">English</SelectItem>
                        <SelectItem value="ar">العربية</SelectItem>
                        <SelectItem value="es">Español</SelectItem>
                        <SelectItem value="fr">Français</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex items-center justify-between">
                    <Label className={textClasses}>{t.theme}</Label>
                    <div className="flex items-center space-x-2">
                      <Sun className={`w-4 h-4 ${textClasses}`} />
                      <Switch checked={isDarkMode} onCheckedChange={setIsDarkMode} />
                      <Moon className={`w-4 h-4 ${textClasses}`} />
                    </div>
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </header>

        <main className="flex flex-col lg:flex-row gap-6 p-6">
          <div className={`w-full lg:w-1/3 ${cardClasses} p-6 rounded-lg shadow-lg`}>
            <div className="flex justify-between items-center mb-4">
              <h2 className={`text-2xl font-semibold ${textClasses}`}>{t.folders}</h2>
              <Button
                size="sm"
                onClick={() => setShowNewFolderDialog(true)}
                className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
              >
                {t.createFolder}
              </Button>
            </div>
            <div className="flex flex-col space-y-3 overflow-y-auto max-h-[500px]">
              {folders.map((folder) => (
                <div
                  key={folder.id}
                  className={`flex items-center justify-between p-3 rounded-md cursor-pointer transition-all duration-200 ${
                    isDarkMode ? "hover:bg-white/10" : "hover:bg-gray-100"
                  } ${selectedFile?.id === folder.id ? (isDarkMode ? "bg-blue-500/20" : "bg-blue-100/50") : ""}`}
                  onClick={() => {
                    setSelectedFile(folder)
                    setCurrentScreen("filesInFolder")
                  }}
                >
                  <div className="flex items-center space-x-3">
                    <folder.icon className={`w-6 h-6 text-${folder.color}-500`} />
                    {editingFolder === folder.id ? (
                      <Input
                        value={newFolderName || folder.name}
                        onChange={(e) => setNewFolderName(e.target.value)}
                        onBlur={() => renameFolder(folder.id, newFolderName || folder.name)}
                        onKeyPress={(e) => e.key === "Enter" && renameFolder(folder.id, newFolderName || folder.name)}
                        autoFocus
                        className={isDarkMode ? "h-8 w-32 bg-slate-800 border-white/20" : "h-8 w-32"}
                      />
                    ) : (
                      <p className={`${textClasses} font-medium`}>{folder.name}</p>
                    )}
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className={`${subtextClasses} text-sm`}>({folder.count})</span>
                    <MoreVertical
                      className={`${subtextClasses} w-4 h-4 cursor-pointer`}
                      onClick={(e) => {
                        e.stopPropagation()
                        setEditingFolder(folder.id)
                        setNewFolderName(folder.name)
                      }}
                    />
                    <X
                      className={`${subtextClasses} w-4 h-4 cursor-pointer`}
                      onClick={(e) => {
                        e.stopPropagation()
                        deleteFolder(folder.id)
                      }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className={`w-full lg:w-2/3 ${cardClasses} p-6 rounded-lg shadow-lg flex flex-col`}>
            <div className="flex justify-between items-center mb-4">
              <h2 className={`text-2xl font-semibold ${textClasses}`}>
                {selectedFile && currentScreen === "filesInFolder" ? selectedFile.name : t.myFiles}
              </h2>
              {selectedFile && currentScreen === "filesInFolder" && (
                <Button
                  size="sm"
                  variant="outline"
                  className={
                    isDarkMode
                      ? "border-white/20 text-white hover:bg-white/10"
                      : "border-gray-200 text-gray-700 hover:bg-gray-100"
                  }
                  onClick={() => setCurrentScreen("upload")}
                >
                  {t.uploadFiles}
                </Button>
              )}
            </div>

            {currentScreen === "filesInFolder" && selectedFile ? (
              <div className="flex flex-col space-y-4 overflow-y-auto max-h-[500px]">
                {Array.from({ length: selectedFile.count }, (_, i) => (
                  <div
                    key={i}
                    className={`flex items-center justify-between p-3 rounded-md transition-all duration-200 ${
                      isDarkMode ? "hover:bg-white/10" : "hover:bg-gray-100"
                    }`}
                  >
                    <div className="flex items-center space-x-3">
                      <FileText className={`${textClasses} w-6 h-6`} />
                      <p className={`${textClasses} font-medium truncate`}>File {i + 1} name...</p>
                    </div>
                    <p className={`${subtextClasses} text-sm`}>{Math.floor(Math.random() * 10) + 1} MB</p>
                  </div>
                ))}
                {selectedFile.count === 0 && <p className={`${subtextClasses} text-center`}>This folder is empty.</p>}
              </div>
            ) : (
              <div
                className={`flex flex-col items-center justify-center h-[300px] rounded-lg border-2 border-dashed ${
                  isDarkMode ? "border-white/30 hover:border-white/50" : "border-gray-300 hover:border-gray-400"
                } transition-colors duration-200 cursor-pointer`}
                onClick={() => {
                  const input = document.getElementById("fileInput")
                  input?.click()
                }}
              >
                <input
                  id="fileInput"
                  type="file"
                  multiple
                  className="hidden"
                  onChange={(e) => {
                    if (e.target.files) {
                      const fileArray = Array.from(e.target.files)
                      setFiles((prev) => [...prev, ...fileArray])
                      setSelectedFile(fileArray[0])
                      setCurrentScreen("upload")
                    }
                  }}
                />
                <CloudUpload className={`${subtextClasses} w-12 h-12 mb-4`} />
                <p className={`${textClasses} text-lg font-medium`}>{t.dragDropFiles}</p>
              </div>
            )}
          </div>
        </main>

        <Dialog open={showNewFolderDialog} onOpenChange={setShowNewFolderDialog}>
          <DialogContent
            className={`${isDarkMode ? "bg-slate-900/95 backdrop-blur-sm border-white/20" : "bg-white/95 backdrop-blur-sm border-gray-200"}`}
          >
            <DialogHeader>
              <DialogTitle className={textClasses}>{t.createFolder}</DialogTitle>
            </DialogHeader>
            <div className="flex flex-col space-y-4">
              <Input
                placeholder="Enter folder name"
                value={newFolderName}
                onChange={(e) => setNewFolderName(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && createNewFolder()}
                className={isDarkMode ? "bg-slate-800 border-white/20" : ""}
              />
              <div className="flex justify-end space-x-4">
                <Button variant="outline" onClick={() => setShowNewFolderDialog(false)}>
                  Cancel
                </Button>
                <Button onClick={createNewFolder}>{t.createFolder}</Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        <footer className="fixed bottom-0 left-0 right-0 p-6 text-center">
          <p className={`${subtextClasses}`}>
            {t.storageUsed}: {storageUsed.toFixed(2)} /{" "}
            {storageLimit === Number.POSITIVE_INFINITY ? "∞" : storageLimit.toFixed(2)} GB
          </p>
        </footer>
      </div>
    )
  }

  if (currentScreen === "uploadComplete") {
    return (
      <div className={`min-h-screen ${themeClasses} transition-all duration-500`}>
        <header className="flex justify-between items-center p-6">
          <h1 className={`text-3xl font-bold ${textClasses}`}>{t.appName}</h1>
          <div className="flex items-center space-x-3">
            <Button
              size="sm"
              variant={walletConnected ? "default" : "outline"}
              onClick={() => setWalletConnected(!walletConnected)}
              className={
                walletConnected
                  ? "bg-green-600 hover:bg-green-700"
                  : isDarkMode
                    ? "border-white/20 text-white hover:bg-white/10"
                    : "border-gray-200 text-gray-700 hover:bg-gray-100"
              }
            >
              {walletConnected ? (
                <>
                  <CheckCircle className="w-4 h-4 mr-2" />
                  {balance.toFixed(2)} π
                </>
              ) : (
                t.connectWallet
              )}
            </Button>
            <Sheet open={isSettingsOpen} onOpenChange={setIsSettingsOpen}>
              <SheetTrigger asChild>
                <Button
                  size="icon"
                  variant="ghost"
                  className={`w-10 h-10 rounded-full ${
                    isDarkMode
                      ? "hover:bg-white/10 text-gray-300 hover:text-white"
                      : "hover:bg-gray-100 text-gray-600 hover:text-gray-900"
                  }`}
                >
                  <Settings className="w-5 h-5" />
                </Button>
              </SheetTrigger>
              <SheetContent
                side="right"
                className={`${
                  isDarkMode
                    ? "bg-slate-900/95 backdrop-blur-sm border-white/20"
                    : "bg-white/95 backdrop-blur-sm border-gray-200"
                }`}
              >
                <SheetHeader>
                  <SheetTitle className={textClasses}>{t.settings}</SheetTitle>
                </SheetHeader>
                <div className="mt-6 space-y-6">
                  <div className="space-y-2">
                    <Label className={textClasses}>{t.language}</Label>
                    <Select value={language} onValueChange={setLanguage}>
                      <SelectTrigger className={isDarkMode ? "bg-slate-800 border-white/20" : ""}>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="en">English</SelectItem>
                        <SelectItem value="ar">العربية</SelectItem>
                        <SelectItem value="es">Español</SelectItem>
                        <SelectItem value="fr">Français</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex items-center justify-between">
                    <Label className={textClasses}>{t.theme}</Label>
                    <div className="flex items-center space-x-2">
                      <Sun className={`w-4 h-4 ${textClasses}`} />
                      <Switch checked={isDarkMode} onCheckedChange={setIsDarkMode} />
                      <Moon className={`w-4 h-4 ${textClasses}`} />
                    </div>
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </header>

        <main className="flex flex-col items-center justify-center min-h-[calc(100vh-120px)] p-6">
          <h1 className={`text-5xl font-bold mb-4 ${textClasses}`}>{t.uploadComplete}</h1>
          <p className={`${subtextClasses} text-lg mb-8 text-center`}>
            {t.cid}: {uploadedCID}
          </p>
          <p className={`${subtextClasses} text-lg mb-8 text-center`}>
            {t.aiAnalysis}: {aiAnalysis}
          </p>
          <Button
            size="lg"
            className="px-8 py-4 text-lg rounded-full shadow-lg bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
            onClick={() => setCurrentScreen("welcome")}
          >
            {t.uploadAnother}
          </Button>
        </main>

        <footer className="absolute bottom-0 left-0 right-0 p-6 text-center">
          <p className={`${subtextClasses}`}>
            {t.storageUsed}: {storageUsed.toFixed(2)} /{" "}
            {storageLimit === Number.POSITIVE_INFINITY ? "∞" : storageLimit.toFixed(2)} GB
          </p>
        </footer>
      </div>
    )
  }

  // Fallback for unexpected currentScreen state
  return null
}
